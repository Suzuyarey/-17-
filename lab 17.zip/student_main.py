from itertools import permutations, combinations
from collections import deque

# Task 1
def number_generator(numbers):
    for number in numbers:
        yield number

# Task 2
def even_number_generator(start, end):
    for number in range(start, end + 1):
        if number % 2 == 0:
            yield number

# Task 3
def odd_number_generator(start, end):
    for number in range(start, end + 1):
        if number % 2 != 0:
            yield number

# Task 4
def fibonacci_generator():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

# Task 5
def prime_number_generator(limit):
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    for number in range(2, limit + 1):
        if is_prime(number):
            yield number

# Task 6
class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def pre_order_traversal(root):
    if root:
        yield root.value
        yield from pre_order_traversal(root.left)
        yield from pre_order_traversal(root.right)

# Task 7
def in_order_traversal(root):
    if root:
        yield from in_order_traversal(root.left)
        yield root.value
        yield from in_order_traversal(root.right)

# Task 8
def post_order_traversal(root):
    if root:
        yield from post_order_traversal(root.left)
        yield from post_order_traversal(root.right)
        yield root.value

# Task 9
def dfs_traversal(graph, start):
    stack, visited = [start], set()
    while stack:
        node = stack.pop()
        if node not in visited:
            yield node
            visited.add(node)
            stack.extend(reversed(graph[node]))

# Task 10
def bfs_traversal(graph, start):
    queue, visited = deque([start]), set()
    while queue:
        node = queue.popleft()
        if node not in visited:
            yield node
            visited.add(node)
            queue.extend(graph[node])

# Task 11
def dict_keys_generator(d):
    for key in d.keys():
        yield key

# Task 12
def dict_values_generator(d):
    for value in d.values():
        yield value

# Task 13
def dict_items_generator(d):
    for item in d.items():
        yield item

# Task 14
def file_lines_generator(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            yield line.strip()

# Task 15
def file_words_generator(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            for word in line.split():
                yield word

# Task 16
def string_chars_generator(s):
    for char in s:
        yield char

# Task 17
def unique_elements_generator(lst):
    seen = set()
    for element in lst:
        if element not in seen:
            seen.add(element)
            yield element

# Task 18
def reverse_list_generator(lst):
    for element in reversed(lst):
        yield element

# Task 19
def cartesian_product_generator(lst1, lst2):
    for item1 in lst1:
        for item2 in lst2:
            yield (item1, item2)

# Task 20
def permutations_generator(lst):
    for perm in permutations(lst):
        yield perm

# Task 21
def combinations_generator(lst):
    for r in range(1, len(lst) + 1):
        for comb in combinations(lst, r):
            yield comb

# Task 22
def tuple_list_generator(lst):
    for item in lst:
        yield item

# Task 23
def parallel_lists_generator(*lists):
    for items in zip(*lists):
        yield items

# Task 24
def flatten_list_generator(nested_list):
    for item in nested_list:
        if isinstance(item, list):
            yield from flatten_list_generator(item)
        else:
            yield item

# Task 25
def nested_dict_generator(nested_dict):
    for key, value in nested_dict.items():
        if isinstance(value, dict):
            yield from nested_dict_generator(value)
        else:
            yield (key, value)

# Task 26
def powers_of_two_generator(n):
    for i in range(n + 1):
        yield 2 ** i

# Task 27
def powers_of_base_generator(base, limit):
    power = 0
    result = 1
    while result <= limit:
        yield result
        power += 1
        result = base ** power

# Task 28
def squares_generator(start, end):
    for number in range(start, end + 1):
        yield number ** 2

# Task 29
def cubes_generator(start, end):
    for number in range(start, end + 1):
        yield number ** 3

# Task 30
def factorials_generator(n):
    def factorial(x):
        if x == 0:
            return 1
        else:
            return x * factorial(x - 1)

    for i in range(n + 1):
        yield factorial(i)

# Task 31
def collatz_sequence_generator(start):
    n = start
    while n != 1:
        yield n
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
    yield 1

# Task 32
def geometric_progression_generator(a, r, limit):
    value = a
    while value <= limit:
        yield value
        value *= r

# Task 33
def arithmetic_progression_generator(a, d, limit):
    value = a
    while value <= limit:
        yield value
        value += d

# Task 34
def running_sum_generator(numbers):
    running_sum = 0
    for number in numbers:
        running_sum += number
        yield running_sum

# Task 35
def running_product_generator(numbers):
    running_product = 1
    for number in numbers:
        running_product *= number
        yield running_product

# Example usages:
if __name__ == "__main__":
    gen = number_generator([1, 2, 3, 4, 5])
    print(next(gen)) # 1
    print(next(gen)) # 2

    gen = even_number_generator(1, 10)
    print(next(gen)) # 2
    print(next(gen)) # 4

    gen = odd_number_generator(1, 10)
    print(next(gen)) # 1
    print(next(gen)) # 3

    gen = fibonacci_generator()
    print(next(gen)) # 0
    print(next(gen)) # 1
    print(next(gen)) # 1

    gen = prime_number_generator(10)
    print(next(gen)) # 2
    print(next(gen)) # 3

    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    gen = pre_order_traversal(root)
    print(next(gen)) # 1
    print(next(gen)) # 2

    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    gen = in_order_traversal(root)
    print(next(gen)) # 2
    print(next(gen)) # 1

    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    gen = post_order_traversal(root)
    print(next(gen)) # 2
    print(next(gen)) # 3

    graph = {
        1: [2, 3],
        2: [4],
        3: [5],
        4: [],
        5: []
    }
    gen = dfs_traversal(graph, 1)
    print(next(gen)) # 1
    print(next(gen)) # 2

    graph = {
        1: [2, 3],
        2: [4],
        3: [5],
        4: [],
        5: []
    }
    gen = bfs_traversal(graph, 1)
    print(next(gen)) # 1
    print(next(gen)) # 2

    gen = dict_keys_generator({'a': 1, 'b': 2, 'c': 3})
    print(next(gen)) # 'a'
    print(next(gen)) # 'b'

    gen = dict_values_generator({'a': 1, 'b': 2, 'c': 3})
    print(next(gen)) # 1
    print(next(gen)) # 2

    gen = dict_items_generator({'a': 1, 'b': 2, 'c': 3})
    print(next(gen)) # ('a', 1)
    print(next(gen)) # ('b', 2)

    # Create an example file for file generators
   
    with open('example.txt', 'w') as f:
        f.write("First line\nSecond line\nThird line\n")

    gen = file_lines_generator('example.txt')
    print(next(gen))  # 'First line'
    print(next(gen))  # 'Second line'

    gen = file_words_generator('example.txt')
    print(next(gen))  # 'First'
    print(next(gen))  # 'line'

    gen = string_chars_generator('hello')
    print(next(gen))  # 'h'
    print(next(gen))  # 'e'

    gen = unique_elements_generator([1, 2, 2, 3, 3, 3, 4])
    print(next(gen))  # 1
    print(next(gen))  # 2

    gen = reverse_list_generator([1, 2, 3, 4, 5])
    print(next(gen))  # 5
    print(next(gen))  # 4

    gen = cartesian_product_generator([1, 2], ['a', 'b'])
    print(next(gen))  # (1, 'a')
    print(next(gen))  # (1, 'b')

    gen = permutations_generator([1, 2, 3])
    print(next(gen))  # (1, 2, 3)
    print(next(gen))  # (1, 3, 2)

    gen = combinations_generator([1, 2, 3])
    print(next(gen))  # (1,)
    print(next(gen))  # (2,)

    gen = tuple_list_generator([('a', 1), ('b', 2)])
    print(next(gen))  # ('a', 1)
    print(next(gen))  # ('b', 2)

    gen = parallel_lists_generator([1, 2, 3], ['a', 'b', 'c'])
    print(next(gen))  # (1, 'a')
    print(next(gen))  # (2, 'b')

    gen = flatten_list_generator([1, [2, 3], [4, [5, 6]]])
    print(next(gen))  # 1
    print(next(gen))  # 2

    gen = nested_dict_generator({'a': 1, 'b': {'c': 2, 'd': 3}})
    print(next(gen))  # ('a', 1)
    print(next(gen))  # ('c', 2)

    gen = powers_of_two_generator(5)
    print(next(gen))  # 1
    print(next(gen))  # 2

    gen = powers_of_base_generator(3, 100)
    print(next(gen))  # 1
    print(next(gen))  # 3

    gen = squares_generator(1, 5)
    print(next(gen))  # 1
    print(next(gen))  # 4

    gen = cubes_generator(1, 3)
    print(next(gen))  # 1
    print(next(gen))  # 8

    gen = factorials_generator(5)
    print(next(gen))  # 1
    print(next(gen))  # 1

    gen = collatz_sequence_generator(6)
    print(next(gen))  # 6
    print(next(gen))  # 3

    gen = geometric_progression_generator(1, 2, 10)
    print(next(gen))  # 1
    print(next(gen))  # 2

    gen = arithmetic_progression_generator(1, 2, 10)
    print(next(gen))  # 1
    print(next(gen))  # 3

    gen = running_sum_generator([1, 2, 3, 4])
    print(next(gen))  # 1
    print(next(gen))  # 3

    gen = running_product_generator([1, 2, 3, 4])
    print(next(gen))  # 1
    print(next(gen))  # 2
